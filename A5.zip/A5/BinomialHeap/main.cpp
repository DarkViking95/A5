#include <iostream>
#include "binomial.h"
#include "customErrorClass.h"

using namespace std;

int main() {
    BinomialHeap bh;
    
    // 1. Test Insertions
    bh.insert(10);
    bh.insert(20);
    bh.insert(5);
    bh.insert(30);
    bh.insert(1);
    bh.insert(14);
    bh.insert(27);
    bh.insert(8);
    bh.insert(3);
    bh.insert(12);
    
    try {
        cout << "--- Initial Heap ---" << endl;
        bh.printHeap();
        cout << "\nCurrent Minimum key: " << bh.findMin() << endl;
        
        // 2. Test deleteMin
        cout << "\n--- Testing deleteMin() ---" << endl;
        int extractedMin = bh.deleteMin();
        cout << "Deleted minimum key: " << extractedMin << endl;
        
        cout << "\nHeap after deleteMin():" << endl;
        bh.printHeap();
        cout << "\nNew Minimum key: " << bh.findMin() << endl;

        // 3. Test decreaseKey
        cout << "\n--- Testing decreaseKey() ---" << endl;
        cout << "Decreasing key 30 to 2..." << endl;
        bh.decreaseKey(30, 2);
        
        cout << "\nHeap after decreaseKey(30, 2):" << endl;
        bh.printHeap();
        cout << "\nNew Minimum key: " << bh.findMin() << endl;

        // 4. Test deleteKey
        cout << "\n--- Testing deleteKey() ---" << endl;
        cout << "Deleting key 14..." << endl;
        bh.deleteKey(14);
        
        cout << "\nHeap after deleteKey(14):" << endl;
        bh.printHeap();

        // 5. Try deleting a key that doesn't exist to test error handling
        cout << "\n--- Testing Error Handling ---" << endl;
        cout << "Attempting to delete key 100..." << endl;
        bh.deleteKey(100); 

    } catch (MyException& e) {
        // This will catch the error thrown by bh.deleteKey(100)
        cout << "\n[EXCEPTION CAUGHT]: " << e.what() << endl;
    } catch (exception& e) {
        // Fallback for standard library exceptions
        cout << "\n[STANDARD EXCEPTION CAUGHT]: " << e.what() << endl;
    }

    return 0;
}